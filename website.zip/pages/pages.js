let mainForContent = document.querySelector("#mainForContent");
mainForContent.innerHTML = homePage();

function choosePage(page) {
  window.scrollTo({ x: 0, y: 0, behavior: "smooth" });
  switch (page) {
    case "aiInMenagement":
      mainForContent.innerHTML = AiInManagement();
      break;
    case "home":
      mainForContent.innerHTML = homePage();
      break;
    case "firstPage":
      mainForContent.innerHTML = firstPage();
      break;
  }
  closeSubMenu();
}
